Link Site:http://20670.hosts.ma-cloud.nl/Bewijzenmap2/BAE/BOVI/PHP/myband/

Fouten vanwege host die niet werkte met mijn site dus search balk werkt niet online.

Link Github:https://github.com/RowyDonker/myBand-master

Link Axure:http://nm7p14.axshare.com
 
Documentatie:
Technisch Ontwerp niet ingeleverd vanwege het niet werken van gebruikte software.
En search wegens online database.
