<?php /* Smarty version Smarty-3.1.18, created on 2016-10-12 14:22:36
         compiled from "views\about.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1282357fe2b0c7e5b20-83834636%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca421bab107b2b775730a59672b523b524b4180f' => 
    array (
      0 => 'views\\about.tpl',
      1 => 1476274902,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1282357fe2b0c7e5b20-83834636',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57fe2b0c8fa840_98572400',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57fe2b0c8fa840_98572400')) {function content_57fe2b0c8fa840_98572400($_smarty_tpl) {?><p> ABOUT </p>
<?php }} ?>
