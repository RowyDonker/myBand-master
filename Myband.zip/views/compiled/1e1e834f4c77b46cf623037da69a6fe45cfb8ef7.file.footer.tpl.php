<?php /* Smarty version Smarty-3.1.18, created on 2016-11-01 16:19:53
         compiled from "views/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14983701975800b2e8bd2963-39039029%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1e1e834f4c77b46cf623037da69a6fe45cfb8ef7' => 
    array (
      0 => 'views/footer.tpl',
      1 => 1478013558,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14983701975800b2e8bd2963-39039029',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5800b2e8c0be23_92469631',
  'variables' => 
  array (
    'footer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5800b2e8c0be23_92469631')) {function content_5800b2e8c0be23_92469631($_smarty_tpl) {?><footer>
<div id="pagenav">
<div id="pages">
    <a href="?action=home&page_nr=1">Page 1</a></li>
    <a href="?action=about&page_nr=2">Page 2</a></li>
    <a href="?action=Verhalen&page_nr=3">Page 3</a></li>
    
</div>
</div>
<p id="Footer"> <?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
</p>
</footer>
</html><?php }} ?>
