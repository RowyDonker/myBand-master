<?php /* Smarty version Smarty-3.1.18, created on 2016-11-03 19:46:38
         compiled from "views/head.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18545774035800b2b85b34e7-58579364%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bae71229d2d60c95598ba3d88740cd5863a4dc88' => 
    array (
      0 => 'views/head.tpl',
      1 => 1478178604,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18545774035800b2b85b34e7-58579364',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5800b2b86922e0_15640336',
  'variables' => 
  array (
    'title' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5800b2b86922e0_15640336')) {function content_5800b2b86922e0_15640336($_smarty_tpl) {?><!DOCTYPE html>

    <head>
       <link
rel="alternate" type="application/rss+xml"
href="" title="Mr.Spoopy">


        <meta charset="utf-8">
        <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/main.css">

    </head>
</head>
    <body>
        <header>
        <p id="Titel">Mr.Spoopy</p>
<img src="img/Creepy.jpg" id="HEADIMG"/>

</header><?php }} ?>
