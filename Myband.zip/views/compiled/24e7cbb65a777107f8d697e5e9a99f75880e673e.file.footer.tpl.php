<?php /* Smarty version Smarty-3.1.18, created on 2016-09-28 16:19:49
         compiled from "views\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:448757ebd053387381-64808640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '24e7cbb65a777107f8d697e5e9a99f75880e673e' => 
    array (
      0 => 'views\\footer.tpl',
      1 => 1475072387,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '448757ebd053387381-64808640',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57ebd0533e9190_83983436',
  'variables' => 
  array (
    'footer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ebd0533e9190_83983436')) {function content_57ebd0533e9190_83983436($_smarty_tpl) {?><footer>
    <p> <?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
</p>
</footer>
</body>
</html><?php }} ?>
