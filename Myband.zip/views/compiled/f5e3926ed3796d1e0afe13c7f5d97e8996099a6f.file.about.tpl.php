<?php /* Smarty version Smarty-3.1.18, created on 2016-11-03 12:12:13
         compiled from "views/about.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16669445075800b2e8b36023-68846420%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5e3926ed3796d1e0afe13c7f5d97e8996099a6f' => 
    array (
      0 => 'views/about.tpl',
      1 => 1478171530,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16669445075800b2e8b36023-68846420',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5800b2e8bae7a9_47514503',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5800b2e8bae7a9_47514503')) {function content_5800b2e8bae7a9_47514503($_smarty_tpl) {?><div style='float:right; width:28%'>
    <h2>MR.SPOOPY</h2>
    <img id="Spoops" src="img/Mr.spoopy.jpg">
    <p id="TEXT">"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"</p>
</div>
<div style='float:right; width:28%'>
    <h2>MAKER VAN DE SITE</h2>
    <img src="img/Gabe.jpg" id="Maker">
    <p id="TEXT">"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"</p>
</div>

<div style='float:right; width:28%'>
   <h2>OVER DE SITE</h2>
   <p id="TEXT">"Deze site is gemaakt voor echte horror liefhebbers of mensen die even een angstmomentje willen, deze site is gebaseerd op online gevonden creepastas waar ander mensen tijd en passie hebben gestoken."
   <h3>Creepypastas</h3>
    <p style="width:72%">Creepypasta zijn internet horror stories, verspreid via forums en verschillende sites om lezers te verontrusten en bang te maken. De naam "Creepypasta" komt van het woord "copypasta", een internet woord voor een stuk text dat word gekopieerd en word geplakd op verschillende sites. Creepypastas zijn soms aangevuld met plaatjes, audio en videos gerelateerd met het verhaal, met bloederige, vervormde, en soms shockerende content. </p>
   </p>
</div>


<?php }} ?>
