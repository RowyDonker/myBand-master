<?php /* Smarty version Smarty-3.1.18, created on 2016-11-02 14:59:12
         compiled from "views/nav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7308038955800c53163e378-70934030%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7b2afeb42efe0637a49cffd0bb94a35338f2c806' => 
    array (
      0 => 'views/nav.tpl',
      1 => 1478095135,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7308038955800c53163e378-70934030',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5800c531683a80_34978511',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5800c531683a80_34978511')) {function content_5800c531683a80_34978511($_smarty_tpl) {?><div class="dropdown">
  <button class="dropbtn">MENU</button>
  <div class="dropdown-content">
   <a href="?action=search">SEARCH</a>
    <a href="?action=home">HOME</a>
    <a href="?action=Verhalen">VERHALEN</a>
    <a href="?action=about">INFO</a>
    <img src="img/Ben.png" id="Ben"/>
  </div>
</div><?php }} ?>
